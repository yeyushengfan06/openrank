import json
import os
import random
from pathlib import Path
from collections import defaultdict

class DataLoader:
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.repos = []
        self.stats = {
            "total_repos": 0,
            "total_activity": 0,
            "total_openrank": 0
        }

    def scan_all(self):
        """Scan directory for all repos."""
        print(f"Scanning {self.data_dir}...")
        
        # Reset
        self.repos = []
        self.stats = {"total_repos": 0, "total_activity": 0, "total_openrank": 0}
        
        for root, dirs, files in os.walk(self.data_dir):
            if "activity.json" in files:
                self._process_repo(Path(root))
        
        self.stats["total_repos"] = len(self.repos)
        print(f"Loaded {len(self.repos)} repositories.")

    def _process_repo(self, path):
        try:
            # Extract name from path (mock/owner/repo)
            parts = path.parts
            # Support both windows and unix paths logic if needed, but parts works well
            # parts[-2] is owner, parts[-1] is repo
            owner = parts[-2]
            name = f"{owner}/{parts[-1]}"
            
            repo_data = {
                "name": name, 
                "owner": owner,
                "path": str(path)
            }
            
            # Load Activity
            with open(path / "activity.json", 'r', encoding='utf-8') as f:
                act = json.load(f)
                repo_data["activity_history"] = act
                repo_data["current_activity"] = list(act.values())[-1]
                self.stats["total_activity"] += repo_data["current_activity"]

            # Load OpenRank
            if (path / "openrank.json").exists():
                with open(path / "openrank.json", 'r', encoding='utf-8') as f:
                    rank = json.load(f)
                    repo_data["openrank_history"] = rank
                    repo_data["current_openrank"] = list(rank.values())[-1]
                    self.stats["total_openrank"] += repo_data["current_openrank"]
            else:
                repo_data["current_openrank"] = 0

            # Load Issue Stats
            if (path / "issue_stats.json").exists():
                with open(path / "issue_stats.json", 'r', encoding='utf-8') as f:
                    repo_data["issue_stats"] = json.load(f)
            
            # Load Contributors
            if (path / "contributors.json").exists():
                with open(path / "contributors.json", 'r', encoding='utf-8') as f:
                    repo_data["contributors"] = json.load(f)

            self.repos.append(repo_data)
        except Exception as e:
            print(f"Error loading {path}: {e}")

    # --- New Analysis Methods ---

    def get_lifecycle_analysis(self):
        """Analyze project lifecycle stages based on recent activity trends."""
        results = {"Growing": [], "Stable": [], "Declining": [], "Critical": []}
        
        for repo in self.repos:
            history = list(repo.get("activity_history", {}).values())
            if len(history) < 6:
                continue
                
            recent_avg = sum(history[-3:]) / 3
            prev_avg = sum(history[-6:-3]) / 3
            
            if prev_avg == 0:
                change = 0
            else:
                change = (recent_avg - prev_avg) / prev_avg
                
            item = {"name": repo["name"], "change": round(change * 100, 1), "value": repo["current_activity"]}
            
            if change > 0.1:
                results["Growing"].append(item)
            elif change < -0.5:
                results["Critical"].append(item)
            elif change < -0.1:
                results["Declining"].append(item)
            else:
                results["Stable"].append(item)
                
        # Sort critical by severity
        results["Critical"] = sorted(results["Critical"], key=lambda x: x["change"])
        return results

    def get_impact_correlation(self):
        """Data for Activity vs OpenRank scatter plot."""
        data = []
        for repo in self.repos:
            data.append([
                repo.get("current_activity", 0),
                repo.get("current_openrank", 0),
                repo["name"],
                repo.get("owner", "other")
            ])
        return data

    def get_ecosystem_radar(self):
        """Compare ecosystem categories."""
        categories = defaultdict(lambda: {"count": 0, "act": 0, "rank": 0, "issues": 0})
        
        for repo in self.repos:
            cat = repo.get("owner", "other")
            categories[cat]["count"] += 1
            categories[cat]["act"] += repo.get("current_activity", 0)
            categories[cat]["rank"] += repo.get("current_openrank", 0)
            
            # Mock issue efficiency score (inverse of resolution time)
            issue_stats = repo.get("issue_stats", {})
            time = issue_stats.get("avg_resolution_time", 15)
            efficiency = max(0, 100 - time * 2) # Simple scoring
            categories[cat]["issues"] += efficiency

        indicators = []
        values = []
        
        # Normalize
        for cat, stats in categories.items():
            count = stats["count"]
            if count == 0: continue
            
            values.append({
                "name": cat,
                "value": [
                    round(stats["act"] / count, 1),
                    round(stats["rank"] / count, 1),
                    round(stats["issues"] / count, 1),
                    count * 10, # Weight by size
                    random.randint(60, 90) # Mock Innovation Score
                ]
            })
            
        return {
            "indicators": [
                {"name": "Avg Activity", "max": 1000},
                {"name": "Avg OpenRank", "max": 100},
                {"name": "Efficiency", "max": 100},
                {"name": "Scale Score", "max": 100},
                {"name": "Innovation", "max": 100}
            ],
            "series": values
        }
    
    def get_developer_talent(self):
        """Analyze contributor patterns."""
        # Aggregated stats
        total_devs = 0
        top_performers = []
        
        for repo in self.repos:
            devs = repo.get("contributors", [])
            total_devs += len(devs)
            for d in devs:
                # Lower threshold to capture more devs, but sort strictly
                if d["commits"] > 20: 
                    top_performers.append({
                        "name": d["name"],
                        "repo": repo["name"].split('/')[-1], # Shorten repo name
                        "commits": d["commits"],
                        "speed": d["response_speed"]
                    })
                    
        # Sort by commits desc
        top_performers.sort(key=lambda x: x["commits"], reverse=True)
        
        return {
            "total_devs": total_devs,
            "core_devs": len([d for d in top_performers if d["commits"] > 100]),
            "top_list": top_performers[:20] # Return top 20 instead of 5
        }

    def get_anomalies(self):
        """Detect statistical anomalies."""
        anomalies = []
        for repo in self.repos:
            history = list(repo.get("activity_history", {}).values())
            if len(history) < 12: continue
            
            # Simple Z-score-like check for last month
            recent = history[-1]
            avg = sum(history[:-1]) / len(history[:-1])
            if avg > 10 and recent < avg * 0.2: # 80% drop
                anomalies.append({
                    "type": "CRASH",
                    "repo": repo["name"],
                    "msg": f"活跃度从 ~{int(avg)} 骤降至 {recent}"
                })
            elif recent > avg * 3 and avg > 10:
                anomalies.append({
                    "type": "SPIKE",
                    "repo": repo["name"],
                    "msg": f"活跃度激增至 {recent} (均值 {int(avg)})"
                })
                
        return anomalies

    def get_ai_insight(self):
        """Mock LLM Analysis of the Ecosystem."""
        # In a real app, we would send 'self.stats' and 'anomalies' to GPT-4
        
        # Analyze overall health
        health_score = "A+"
        if self.stats["total_activity"] < 5000: health_score = "B"
        
        # Generate dynamic text based on anomalies
        anomalies = self.get_anomalies()
        risk_text = "No critical risks detected."
        if anomalies:
            risk_text = f"Detected {len(anomalies)} anomalies. Immediate attention required for {anomalies[0]['repo']}."
            
        return {
            "summary": f"Ecosystem health is rated {health_score}. Total activity is stable with {self.stats['total_repos']} active repositories.",
            "risk_assessment": risk_text,
            "recommendation": "Suggest allocating more resources to 'Declining' projects to prevent churn. Consider recognizing top contributors in the 'Elite' tier."
        }

    def get_forecast(self):
        """Simple Linear Regression Forecast for next 6 months."""
        # Get aggregated activity
        agg = self.get_aggregated_trends("activity")
        y = agg["values"][-12:] # Last 12 months
        x = list(range(len(y)))
        
        # Simple slope calculation (Linear Regression)
        n = len(x)
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(i*j for i, j in zip(x, y))
        sum_xx = sum(i*i for i in x)
        
        slope = (n*sum_xy - sum_x*sum_y) / (n*sum_xx - sum_x**2)
        intercept = (sum_y - slope*sum_x) / n
        
        # Predict next 6 months
        future_dates = []
        future_values = []
        last_date = agg["dates"][-1] # "YYYY-MM"
        
        # Parse date manually to avoid heavy libs if needed, but here simple string logic
        y, m = map(int, last_date.split('-'))
        
        for i in range(1, 7):
            m += 1
            if m > 12:
                m = 1
                y += 1
            future_dates.append(f"{y}-{m:02d}")
            future_values.append(max(0, intercept + slope * (n + i - 1)))
            
        return {
            "dates": future_dates,
            "values": future_values
        }

    def get_overview_stats(self):
        return self.stats

    def get_rankings(self):
        # Sort by OpenRank
        by_rank = sorted(self.repos, key=lambda x: x.get("current_openrank", 0), reverse=True)[:10]
        # Sort by Activity
        by_act = sorted(self.repos, key=lambda x: x.get("current_activity", 0), reverse=True)[:10]
        
        return {
            "top_openrank": [{"name": r["name"], "value": r["current_openrank"]} for r in by_rank],
            "top_activity": [{"name": r["name"], "value": r["current_activity"]} for r in by_act]
        }
    
    def get_bus_factor_distribution(self):
        """Mock Bus Factor Distribution (Risk Analysis)"""
        # In real scenario, calculate from contributors
        return [
            {"name": "High Risk (BF=1)", "value": 15},
            {"name": "Medium Risk (BF=2-3)", "value": 35},
            {"name": "Healthy (BF>3)", "value": 50}
        ]
        
    def get_contributor_retention(self):
        """Mock Contributor Retention Heatmap Data (Cohort Analysis)"""
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
        data = []
        for i in range(6):
            for j in range(6):
                if j >= i:
                    val = max(10, 100 - (j-i)*15 + random.randint(-5, 5))
                    data.append([i, j, val])
        return {"months": months, "data": data}
        
    def get_time_distribution(self):
        """Mock Time Distribution (PR Merge Time vs Issue Close Time)"""
        # Boxplot data format
        return {
            "categories": ["Cloud Native", "AI Labs", "Web Frameworks", "Databases"],
            "pr_merge": [
                [1, 2, 5, 10, 20],   # Cloud
                [2, 5, 12, 25, 40],  # AI
                [0.5, 1, 3, 7, 14],  # Web
                [5, 10, 20, 45, 90]  # DB
            ]
        }

    def get_community_health(self):
        """Mock Community Health Index (Scatter Plot Data)"""
        # X: Activity, Y: Health Score, Size: Contributors
        data = []
        for repo in self.repos:
            act = repo.get("current_activity", 0)
            health = min(100, (act / 10) + random.randint(-10, 20))
            contribs = random.randint(5, 200)
            data.append([act, health, contribs, repo["name"]])
        return data

    def get_issue_resolution_stats(self):
        """Mock Issue Resolution (Bar Chart)"""
        # Categories: <1h, <1d, <1w, <1m, >1m
        return {
            "categories": ["< 1 Hour", "< 1 Day", "< 1 Week", "< 1 Month", "> 1 Month"],
            "values": [
                random.randint(50, 150),
                random.randint(200, 400),
                random.randint(150, 300),
                random.randint(50, 100),
                random.randint(10, 50)
            ]
        }

    def get_pr_lifecycle(self):
        """Mock PR Lifecycle (Sankey Diagram Data)"""
        return {
            "nodes": [
                {"name": "Opened PRs"},
                {"name": "CI Passed"}, {"name": "CI Failed"},
                {"name": "Review Required"},
                {"name": "Changes Requested"}, {"name": "Approved"},
                {"name": "Merged"}, {"name": "Closed"}
            ],
            "links": [
                {"source": "Opened PRs", "target": "CI Passed", "value": 80},
                {"source": "Opened PRs", "target": "CI Failed", "value": 20},
                {"source": "CI Passed", "target": "Review Required", "value": 75},
                {"source": "Review Required", "target": "Changes Requested", "value": 30},
                {"source": "Review Required", "target": "Approved", "value": 40},
                {"source": "Changes Requested", "target": "Approved", "value": 25},
                {"source": "Approved", "target": "Merged", "value": 60},
                {"source": "CI Failed", "target": "Closed", "value": 15}
            ]
        }

    def get_aggregated_trends(self, metric):
        """Aggregate metric across all repos over time."""
        agg = defaultdict(float)
        key = "activity_history" if metric == "activity" else "openrank_history"
        
        for repo in self.repos:
            history = repo.get(key, {})
            for date, val in history.items():
                agg[date] += val
                
        # Sort by date
        sorted_dates = sorted(agg.keys())
        return {
            "dates": sorted_dates,
            "values": [agg[d] for d in sorted_dates]
        }

    def get_text_summary(self):
        """Generate a text summary of the ecosystem for LLM context."""
        overview = self.get_overview_stats()
        rankings = self.get_rankings()
        anomalies = self.get_anomalies()
        
        summary = f"""
【生态概览】
- 监控仓库总数: {overview['total_repos']}
- 总活跃度: {int(overview['total_activity'])}
- 总影响力(OpenRank): {int(overview['total_openrank'])}

【排名靠前项目 (Top 5 OpenRank)】
{', '.join([f"{r['name']}({int(r['value'])})" for r in rankings['top_openrank'][:5]])}

【异常检测】
"""
        if anomalies:
            for a in anomalies[:5]: # Limit to 5
                summary += f"- {a['repo']}: {a['type']} ({a['msg']})\n"
        else:
            summary += "- 无明显异常。\n"
            
        return summary
