import os
import pandas as pd
import json
from pathlib import Path

def process_upload(file, project_name, metric_type):
    """
    Process uploaded file and save as OpenDigger format JSON.
    """
    try:
        # Determine file type
        filename = file.filename
        if filename.endswith('.csv'):
            df = pd.read_csv(file)
        elif filename.endswith(('.xls', '.xlsx')):
            df = pd.read_excel(file)
        else:
            return False, "Unsupported file format. Please use CSV or Excel."

        # Check columns
        # Expecting at least two columns: Date/Time and Value
        if df.shape[1] < 2:
            return False, "File must have at least 2 columns (Date, Value)."
            
        # Assume 1st column is date, 2nd is value
        date_col = df.columns[0]
        val_col = df.columns[1]
        
        # Format data: {"YYYY-MM": value}
        # Try to parse dates
        try:
            df[date_col] = pd.to_datetime(df[date_col])
        except:
            return False, f"Could not parse date column '{date_col}'."
            
        data = {}
        for _, row in df.iterrows():
            try:
                date_str = row[date_col].strftime('%Y-%m')
                val = float(row[val_col])
                data[date_str] = val
            except:
                continue
            
        if not data:
            return False, "No valid data parsed."

        # Save to file
        # Directory: opendigger_data/custom/{project_name}/
        base_dir = Path("opendigger_data") / "custom" / project_name
        base_dir.mkdir(parents=True, exist_ok=True)
        
        # Determine filename based on metric
        target_file = base_dir / f"{metric_type}.json"
        
        with open(target_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
            
        # Ensure activity.json exists for DataLoader detection
        if metric_type != 'activity' and not (base_dir / "activity.json").exists():
            # Create dummy activity to allow detection
            dummy_act = {k: 0 for k in data.keys()}
            with open(base_dir / "activity.json", 'w', encoding='utf-8') as f:
                json.dump(dummy_act, f, indent=2)
                
        return True, f"Successfully imported {len(data)} records for {project_name}."
        
    except Exception as e:
        return False, f"Error processing file: {str(e)}"
