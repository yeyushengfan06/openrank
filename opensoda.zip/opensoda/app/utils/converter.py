import pandas as pd
import json
import os
from datetime import datetime

def process_upload(file_storage, project_name, metric_type, base_dir="opendigger_data"):
    """
    Process an uploaded file (CSV/Excel) and convert it to OpenGalaxy JSON format.
    
    Args:
        file_storage: Flask file object
        project_name: Name of the project (folder name)
        metric_type: 'activity' or 'openrank'
        base_dir: Root data directory
    """
    filename = file_storage.filename.lower()
    
    # Read file
    try:
        if filename.endswith('.csv'):
            df = pd.read_csv(file_storage)
        elif filename.endswith(('.xls', '.xlsx')):
            df = pd.read_excel(file_storage)
        else:
            return False, "不支持的文件格式。请上传 .csv 或 .xlsx 文件。"
    except Exception as e:
        return False, f"文件读取失败: {str(e)}"

    # Normalize columns
    # We expect 'date'/'time' and 'value'/'count' columns
    cols = [c.lower() for c in df.columns]
    date_col = next((c for c in cols if 'date' in c or 'time' in c or 'month' in c), None)
    val_col = next((c for c in cols if 'val' in c or 'count' in c or 'score' in c or 'num' in c), None)

    if not date_col or not val_col:
        # Fallback: assume 1st column is date, 2nd is value
        if len(df.columns) >= 2:
            date_col = df.columns[0]
            val_col = df.columns[1]
        else:
            return False, "无法识别数据列。请确保包含日期(Date)和数值(Value)列。"

    # Convert to standard format { "YYYY-MM": value }
    result = {}
    try:
        # Use original column names for access
        real_date_col = df.columns[cols.index(date_col)]
        real_val_col = df.columns[cols.index(val_col)]
        
        for _, row in df.iterrows():
            d = row[real_date_col]
            v = row[real_val_col]
            
            # Parse date to YYYY-MM
            if isinstance(d, str):
                d = pd.to_datetime(d)
            if isinstance(d, (datetime, pd.Timestamp)):
                key = d.strftime("%Y-%m")
            else:
                continue # Skip invalid dates
                
            # Parse value
            try:
                val = float(v)
            except:
                val = 0
                
            result[key] = val
            
    except Exception as e:
        return False, f"数据转换失败: {str(e)}"

    # Save to file
    # Structure: opendigger_data/custom/<project_name>/<metric_type>.json
    target_dir = os.path.join(base_dir, "custom", project_name)
    os.makedirs(target_dir, exist_ok=True)
    
    target_file = os.path.join(target_dir, f"{metric_type}.json")
    
    try:
        with open(target_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2)
    except Exception as e:
        return False, f"文件保存失败: {str(e)}"
        
    return True, "导入成功"
