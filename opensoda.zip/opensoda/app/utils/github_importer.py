import requests
import json
import os
from pathlib import Path

def fetch_opendigger_data(repo_name):
    """
    Fetch data from OpenDigger API for a given repo (owner/repo).
    """
    try:
        if '/' not in repo_name:
            return False, "Invalid repo format. Use owner/repo."
            
        owner, repo = repo_name.split('/')
        
        # OpenDigger API Base
        base_url = f"https://oss.x-lab.info/open_digger/github/{owner}/{repo}"
        
        # Local output directory
        output_dir = Path("opendigger_data") / "github" / owner / repo
        output_dir.mkdir(parents=True, exist_ok=True)
        
        success_count = 0
        
        # List of metrics to fetch
        metrics = [
            "activity", 
            "openrank", 
            "stars", 
            "technical_fork", 
            "participants"
        ]
        
        for metric in metrics:
            try:
                print(f"Fetching {metric} for {repo_name}...")
                resp = requests.get(f"{base_url}/{metric}.json", timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    with open(output_dir / f"{metric}.json", 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2)
                    success_count += 1
                else:
                    print(f"{metric} not found: {resp.status_code}")
            except Exception as e:
                print(f"Error fetching {metric}: {e}")
            
        if success_count == 0:
            return False, "Failed to fetch data. Please check if the repository is supported by OpenDigger."
            
        return True, f"Successfully imported data for {repo_name}."
        
    except Exception as e:
        return False, f"Import error: {str(e)}"

def refresh_all_repos():
    """
    Refresh data for all locally stored GitHub repositories.
    """
    base_dir = Path("opendigger_data") / "github"
    if not base_dir.exists():
        return 0, ["No repositories found to refresh. Please import a repository first."]
        
    updated_count = 0
    errors = []
    
    # Iterate owner/repo
    for owner_dir in base_dir.iterdir():
        if not owner_dir.is_dir(): continue
        
        for repo_dir in owner_dir.iterdir():
            if not repo_dir.is_dir(): continue
            
            repo_name = f"{owner_dir.name}/{repo_dir.name}"
            print(f"Refreshing {repo_name}...")
            
            success, msg = fetch_opendigger_data(repo_name)
            if success:
                updated_count += 1
            else:
                errors.append(f"{repo_name}: {msg}")
                
    return updated_count, errors

