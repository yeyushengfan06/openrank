import requests
import json
import os
import time

def fetch_opendigger_data(repo_name, base_dir="opendigger_data"):
    """
    Fetch data from OpenDigger API for a given GitHub repository.
    
    Args:
        repo_name: "owner/repo" format
        base_dir: Root data directory
    """
    # OpenDigger API base URL
    BASE_URL = "https://oss.x-lab.info/open_digger/github"
    
    # We will fetch a few key metrics
    metrics = {
        "activity": "activity.json",
        "openrank": "openrank.json",
        "issue_response_time": "issue_response_time.json" # Approximates issue_stats
    }
    
    # Target directory: opendigger_data/imported/<owner>/<repo>
    # Note: Our DataLoader expects owner/repo structure
    owner, name = repo_name.split('/')
    target_dir = os.path.join(base_dir, "imported", owner, name)
    os.makedirs(target_dir, exist_ok=True)
    
    success_count = 0
    
    for metric_key, endpoint in metrics.items():
        url = f"{BASE_URL}/{repo_name}/{endpoint}"
        try:
            print(f"Fetching {url}...")
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                
                # Transform data if necessary to match our mock format
                if metric_key == "issue_response_time":
                    # Convert complex structure to simplified stats if needed
                    # But for now, let's just save it as is and handle reading later?
                    # Actually, our DataLoader expects "issue_stats.json" with specific structure.
                    # Let's try to adapt or just save raw for now.
                    # For simplicity in this demo, we'll map OpenDigger's standard output to our expected files
                    
                    # 1. Activity & OpenRank are usually YYYY-MM -> value, which matches.
                    pass 
                
                # Save
                filename = f"{metric_key}.json"
                if metric_key == "issue_response_time":
                    # We might need to fake issue_stats.json from this
                    # Let's save as issue_stats.json for now but we might need to adapt schema
                    filename = "issue_stats_raw.json" 
                
                with open(os.path.join(target_dir, filename), 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                success_count += 1
            else:
                print(f"Failed to fetch {metric_key}: {resp.status_code}")
        except Exception as e:
            print(f"Error fetching {metric_key}: {str(e)}")
            
    if success_count == 0:
        return False, "未找到该仓库数据或 OpenDigger 暂未收录"
        
    return True, f"成功导入 {repo_name} 的数据"
