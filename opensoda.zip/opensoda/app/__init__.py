from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
from app.utils.data_loader import DataLoader
from app.utils.llm_service import chat_with_qwen
from app.utils.converter import process_upload
from app.utils.github_importer import fetch_opendigger_data, update_all_imported_repos
import os

def create_app():
    app = Flask(__name__)
    CORS(app)
    
    # Initialize Data Loader
    data_loader = DataLoader("opendigger_data")
    data_loader.scan_all()
    
    @app.route('/')
    def index():
        return render_template('dashboard.html')

    @app.route('/api/chat', methods=['POST'])
    def chat():
        data = request.json
        user_query = data.get('query')
        use_fallback = data.get('use_fallback', False) # Check if user requested fallback
        
        if not user_query:
            return jsonify({"error": "Missing query"}), 400
            
        summary = data_loader.get_text_summary()
        response = chat_with_qwen(user_query, summary, use_fallback=use_fallback)
        return jsonify(response)

    @app.route('/api/set_key', methods=['POST'])
    def set_key():
        data = request.json
        api_key = data.get('api_key')
        if not api_key or not api_key.startswith('sk-'):
            return jsonify({"success": False, "message": "无效的 API Key 格式"}), 400
            
        # Update current process environment
        os.environ["DASHSCOPE_API_KEY"] = api_key
        
        # Write to .env file for persistence
        env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')
        try:
            with open(env_path, 'w') as f:
                f.write(f"DASHSCOPE_API_KEY={api_key}\n")
            return jsonify({"success": True, "message": "API Key 已保存并生效"})
        except Exception as e:
            return jsonify({"success": False, "message": f"保存失败: {str(e)}"}), 500

    @app.route('/api/upload', methods=['POST'])
    def upload_data():
        if 'file' not in request.files:
            return jsonify({"success": False, "message": "未找到上传文件"}), 400
            
        file = request.files['file']
        project = request.form.get('project')
        metric = request.form.get('metric')
        
        if not file or not project or not metric:
            return jsonify({"success": False, "message": "缺少必要参数"}), 400
            
        success, msg = process_upload(file, project, metric)
        
        if success:
            # Refresh data
            data_loader.scan_all()
            return jsonify({"success": True, "message": msg})
        else:
            return jsonify({"success": False, "message": msg}), 500

    @app.route('/api/import/github', methods=['POST'])
    def import_github():
        data = request.json
        repo = data.get('repo') # "owner/repo"
        
        if not repo or '/' not in repo:
            return jsonify({"success": False, "message": "格式错误，请使用 owner/repo"}), 400
            
        success, msg = fetch_opendigger_data(repo)
        
        if success:
            data_loader.scan_all()
            return jsonify({"success": True, "message": msg})
        else:
            return jsonify({"success": False, "message": msg}), 500

    @app.route('/api/refresh', methods=['POST'])
    def refresh_data():
        """Re-fetch data for all imported repos."""
        s_count, f_count, msg = update_all_imported_repos()
        
        # Always rescan to pick up changes (or at least acknowledge them)
        data_loader.scan_all()
        
        return jsonify({
            "success": True, 
            "message": f"刷新完成: 成功 {s_count} 个, 失败 {f_count} 个",
            "stats": {"success": s_count, "fail": f_count}
        })
         
    @app.route('/api/overview')
    def get_overview():
        """Get high-level ecosystem stats."""
        return jsonify(data_loader.get_overview_stats())

    @app.route('/api/rankings')
    def get_rankings():
        """Get top repos by different metrics."""
        return jsonify(data_loader.get_rankings())

    @app.route('/api/trends/<metric>')
    def get_trends(metric):
        """Get aggregated trends over time."""
        return jsonify(data_loader.get_aggregated_trends(metric))

    @app.route('/api/analysis/bus_factor')
    def get_bus_factor():
        return jsonify(data_loader.get_bus_factor_distribution())

    @app.route('/api/analysis/retention')
    def get_retention():
        return jsonify(data_loader.get_contributor_retention())
        
    @app.route('/api/analysis/efficiency')
    def get_efficiency():
        return jsonify(data_loader.get_time_distribution())

    @app.route('/api/analysis/community_health')
    def get_community_health():
        return jsonify(data_loader.get_community_health())

    @app.route('/api/analysis/issue_resolution')
    def get_issue_resolution():
        return jsonify(data_loader.get_issue_resolution_stats())

    @app.route('/api/analysis/pr_lifecycle')
    def get_pr_lifecycle():
        return jsonify(data_loader.get_pr_lifecycle())

    @app.route('/api/analysis/lifecycle')
    def get_lifecycle():
        return jsonify(data_loader.get_lifecycle_analysis())

    @app.route('/api/analysis/impact_correlation')
    def get_impact_correlation():
        return jsonify(data_loader.get_impact_correlation())

    @app.route('/api/analysis/ecosystem_radar')
    def get_ecosystem_radar():
        return jsonify(data_loader.get_ecosystem_radar())

    @app.route('/api/analysis/developer_talent')
    def get_developer_talent():
        return jsonify(data_loader.get_developer_talent())

    @app.route('/api/analysis/anomalies')
    def get_anomalies():
        return jsonify(data_loader.get_anomalies())

    @app.route('/api/ai/insight')
    def get_ai_insight():
        return jsonify(data_loader.get_ai_insight())

    @app.route('/api/trends/forecast')
    def get_forecast():
        return jsonify(data_loader.get_forecast())
        
    return app
